import * as React from 'react';
import './index.scss';

class Home extends React.PureComponent {
  public render(): JSX.Element {
    return <div className={'container'}>Home</div>;
  }
}

export default Home;
