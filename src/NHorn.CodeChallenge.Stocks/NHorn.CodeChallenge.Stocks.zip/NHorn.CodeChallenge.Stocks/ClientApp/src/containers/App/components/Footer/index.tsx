import React from 'react';
import './index.scss';

class Footer extends React.PureComponent {
  public render(): JSX.Element {
    return <footer>made by mikkel n horn</footer>;
  }
}

export default Footer;
