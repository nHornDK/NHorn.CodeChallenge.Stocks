import { ReactComponent as HomeIcon } from './home-24px.svg';

export { HomeIcon };
