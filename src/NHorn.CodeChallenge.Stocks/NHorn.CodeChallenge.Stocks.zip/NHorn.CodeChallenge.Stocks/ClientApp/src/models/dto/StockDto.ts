export interface StockDto
{
	id: string;
	symbol: string;
	bidPrice: number;
	askPrice: number;
}
